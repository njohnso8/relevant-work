"""
A class to represent seasons of the year.
It should provide the following functionality:
     initialize with approximate dates for seasons: Winter, spring, summer, fall
     A function to lookup the season based on a given date.
"""

class SeasonCalculator:
    