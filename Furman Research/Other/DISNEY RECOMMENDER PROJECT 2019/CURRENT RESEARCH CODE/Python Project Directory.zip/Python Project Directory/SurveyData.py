import UserSurvey
import Utilities

class SurveyData:

    def __init__(self):
        self.__listOfSurveys = [] 

    def __init__(self, listOfSurveys = []):
        self.__listOfSurveys = listOfSurveys

    def addUserSurvey(self, userSurvey):
        self.__listOfSurveys.append(userSurvey)
#        listOfStringSurveys = [str(item) for item in self.__listOfSurveys]
#        s = ","
#        return s.join(listOfStringSurveys)

    def __buildCSV(self):
        """Build the string-based representation of the survey data (including metadata)"""
        results = [survey.buildCSV() for survey in self.__listOfSurveys]
        entireFile = ''.join(results)
        return entireFile

    def writeCSV(filename):
        """Actually write the content to the output file."""
        
        #
        # TODO: Write the header row to the file.
        # This must include NEW columns we are adding from the metadata
        #
        
        outFile = Utilities.safe_open(filename, "w");
        outFile.write(self.__buildCSV())
        outFile.close()
        
    def compute(self, room_data, age_categories):
        """Initiate metadata computations"""
        for survey in self.__listOfSurveys:
            survey.compute(room_data, age_categories)
        
        
    def __str__(self):
        return self.__buildCSV()

def test():
    sd = SurveyData()

    print(sd)

if __name__ == "__main__":
    test()
