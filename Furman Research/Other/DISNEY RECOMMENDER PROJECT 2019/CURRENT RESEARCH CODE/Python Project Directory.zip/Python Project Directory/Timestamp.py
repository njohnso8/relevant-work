"""
    This is a utility class for representing a date, time, etc.
    Input of a date should be a string similar to what is found in our data: month / day / year as well as time
    Parse that string in the constructor
    Provide public methods for accessing date information (month, day, year, etc.)
"""

class Timestamp:
    