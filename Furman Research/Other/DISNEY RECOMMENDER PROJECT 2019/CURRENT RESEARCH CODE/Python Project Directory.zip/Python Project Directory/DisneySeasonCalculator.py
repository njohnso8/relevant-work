"""
A class to represent Disney seasons of the year.
It should provide the following functionality:
     initialize with approximate dates for Disney seasons: all festivals, parties, special times, etc.
     A function to lookup the Disney season based on a given date.
"""

class DisneySeasonCalculator:
    