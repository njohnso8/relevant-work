"""
Created on Wed Jun  5 13:47:22 2019

@author: rebeccawilhelmi

A list of all the global constants for this project
"""

#
###################
#
# Data Files
#
###################
#

ORIGINAL_SURVEY_DATA_FILE = "MASTER WDW Hotel Survey Data.csv"
HOTEL_ROOM_DATA_FILE = "raw_roominfo.csv"
SURVEY_DATA_OUTPUT_FILE = "output_survey_data.csv"


#
###################
#
# Age Categories Grouping
#
###################
#

NEWBORNS = 1
TODDLERS = 4
YOUNG_CHILDREN = 8
PRE_TEENS = 12
TEENS = 17
YOUNG_ADULTS = 20
OLDER_YOUNG_ADULTS = 25
ADULTS_WITH_KIDS = 35
MIDDLE_AGED_ADULTS = 50
PRE_RETIREMENT_ADULTS = 65
MAXIMUM_AGE = 120